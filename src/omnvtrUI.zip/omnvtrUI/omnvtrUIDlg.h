
// omnvtrUIDlg.h : header file
//

#pragma once


// ComnvtrUIDlg dialog
class ComnvtrUIDlg : public CDHtmlDialog
{
// Construction
public:
	ComnvtrUIDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_OMNVTRUI_DIALOG, IDH = IDR_HTML_OMNVTRUI_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	HRESULT OnButtonOK(IHTMLElement *pElement);
	HRESULT OnButtonCancel(IHTMLElement *pElement);

// Implementation
protected:
	HICON m_hIcon;

    STDMETHODIMP ShowContextMenu(DWORD dwID, POINT *ppt, IUnknown *pcmdtReserved, IDispatch *pdispReserved)
    {
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE TranslateAccelerator(LPMSG lpMsg, const GUID *pguidCmdGroup, DWORD nCmdID)
    {
        if (lpMsg && lpMsg->message == WM_KEYDOWN &&
            (
                lpMsg->wParam == VK_F5 ||
                lpMsg->wParam == VK_CONTROL ||
                lpMsg->wParam == VK_BACK
            ))
            return S_OK;
        return CDHtmlDialog::TranslateAccelerator(lpMsg, pguidCmdGroup, nCmdID);
    }
#if 0
    BOOL PreTranslateMessage(MSG* pMsg)
    {
        if(pMsg->message == WM_RBUTTONDOWN || pMsg->message == WM_RBUTTONDBLCLK)
            return TRUE;
        return CDHtmlDialog::PreTranslateMessage(pMsg);
    }
#endif

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	DECLARE_DHTML_EVENT_MAP()
};
